"""Dashboard module package."""
