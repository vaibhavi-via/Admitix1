"""Chat module package."""
