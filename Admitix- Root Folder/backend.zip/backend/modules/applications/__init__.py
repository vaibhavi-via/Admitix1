"""Applications module package."""
