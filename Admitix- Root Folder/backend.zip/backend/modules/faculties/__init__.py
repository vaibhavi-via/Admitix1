"""Faculties module package."""
