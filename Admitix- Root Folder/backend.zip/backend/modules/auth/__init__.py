"""Authentication module package."""
