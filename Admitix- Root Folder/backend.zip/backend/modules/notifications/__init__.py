"""Notifications module package."""
