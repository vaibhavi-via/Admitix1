"""Courses module package."""
