"""AI verification module package."""
