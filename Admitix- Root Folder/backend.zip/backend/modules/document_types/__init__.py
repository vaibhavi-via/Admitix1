"""Document types module package."""
