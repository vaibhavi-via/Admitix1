"""Student educational-detail module."""
