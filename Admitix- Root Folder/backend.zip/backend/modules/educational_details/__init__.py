"""Student educational-detail module."""
