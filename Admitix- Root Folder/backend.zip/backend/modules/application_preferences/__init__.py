"""Application course-preference module."""
