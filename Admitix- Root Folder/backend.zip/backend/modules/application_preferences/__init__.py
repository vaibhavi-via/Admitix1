"""Application course-preference module."""
