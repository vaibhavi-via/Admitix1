"""Departments module package."""
