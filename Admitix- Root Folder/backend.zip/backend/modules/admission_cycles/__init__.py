"""Admission cycle module package."""
