"""Database layer: engine, session factory, declarative base, and seed data."""
